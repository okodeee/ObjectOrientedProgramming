#include <iostream>
#include <string>
using namespace std;

/* ���� 1��
class Base {
protected: //Base type
	void print_base() { cout << "Base" << endl; }
};

// Base type  |  ��� type   | Derived type
// private    |  �������    | ���� �Ұ� (Base�Լ��� ����)
// protected  |  �������    | private
// public     | private/protected | private
// public     | public       | public

class Derived : private Base {
public:
	void print_derived() {
		print_base();
		cout << "Derived" << endl;
	}
};

int main() {
	Base base;
	Derived derived;

	derived.print_derived();

	return 0;
}
*/

/* ���� 2��
// �Լ� �����ε�: int    sum(int x, int y),
//                double sum(double x, double y)
//                float  sum(float x, float y, float z)
// �Լ� �������̵� (����� Ư���� ��� ���)
//void Text::append(string _extra)
//void Fancy::append(string _extra)

class Text {
private:
	string text;
public:
	Text(string _t) : text(_t) {}
	virtual string get() { return text; }
	virtual void append(string _extra) { text += _extra; }
};

class FancyText : public Text {
private:
	string left_brac;
	string right_brac;
	string connector;
public:
	FancyText(string _t, string _lb, string _rb, string _con) :
		Text::Text(_t), left_brac(_lb), right_brac(_rb), connector(_con) {}
	string get() override { return left_brac + Text::get() + right_brac; }
	void append(string _extra) override { Text::append(connector + _extra); }
};

class FixedText : public Text {
public:
	FixedText() : Text::Text("FIXED") {}
	void append(string _extra) override {}
};

int main() {
	Text t1("Plain");
	t1.append("A");
	cout << t1.get() << endl;

	FancyText t2("Fancy", "<<", ">>", "***");
	t2.append("A");
	cout << t2.get() << endl;

	FixedText t3;
	t3.append("A");
	cout << t3.get() << endl;
	t1 = t2;

	return 0;
}
*/

/* ���� 1��
class Polygon {
public:
	Polygon() {}
	Polygon(int point, float length) : mPoint(point), mLength(length) {}
	~Polygon() {}
	virtual void calcPerimeter() { cout << "Perimeter: empty" << endl; }
	virtual void calcArea() { cout << "Area: empty" << endl; }
protected:
	int mPoint;
	double mLength;
};

class Rectangle : public Polygon {
public:
	Rectangle() {}
	Rectangle(int point, float length) : Polygon(point, length) {}
	~Rectangle() {}
	void calcPerimeter() override { cout << "Perimeter: " << mPoint * mLength << endl; }
	void calcArea() override { cout << "Area: " << mLength * mLength << endl; }
};

int main() {
	Polygon pol;
	Rectangle rec(4, 10);

	cout << "--- Polygon class ---" << endl;
	pol.calcPerimeter();
	pol.calcArea();
	cout << "--- Rectangle class ---" << endl;
	rec.calcPerimeter();
	rec.calcArea();

	return 0;
}
*/

/* ���� 2��
class Polygon {
public:
	Polygon() {}
	Polygon(int point, float length) : mPoint(point), mLength(length) {}
	~Polygon() {}
	virtual void calcPerimeter() { cout << "Perimeter: empty" << endl; }
	virtual void calcArea() { cout << "Area: empty" << endl; }
protected:
	int mPoint;
	double mLength;
};

class Rectangle : public Polygon {
public:
	Rectangle() {}
	Rectangle(int point, float length) : Polygon(point, length) {}
	~Rectangle() {}
	void calcPerimeter() override { cout << "Perimeter: " << mPoint * mLength << endl; }
	void calcArea() override { cout << "Area: " << mLength * mLength << endl; }
};

class Triangle : public Polygon {
public:
	Triangle() {}
	Triangle(int point, float length) : Polygon(point, length) {}
	~Triangle() {}
	void calcPerimeter() override { cout << "Perimeter: " << mPoint*mLength << endl; }
	void calcArea() override { cout << "Area: " << mLength * mLength * sqrt(3) / 4 << endl; }
};

class Circle : public Polygon {
public:
	Circle() {}
	Circle(int point, float length) : Polygon(point, length) {}
	~Circle() {}
	void calcPerimeter() override { cout << "Perimeter: " << 3.14 * 2 * mLength << endl; }
	void calcArea() override { cout << "Area: " << mLength * mLength*3.14 << endl; }
};

int main() {
	Triangle tri(3, 10);
	Rectangle rec(4, 10);
	Circle cir(0, 5);
	cout << "--- Triangle class ---" << endl;
	tri.calcPerimeter();
	tri.calcArea();
	cout << "--- Rectangle class ---" << endl;
	rec.calcPerimeter();
	rec.calcArea();
	cout << "--- Circle class ---" << endl;
	cir.calcPerimeter();
	cir.calcArea();

	return 0;
}
*/

/* ���� 3��
class Train {
public:
	Train() {}
	Train(int people) { }
	~Train() {}
	virtual int station(int takeOff, int takeOn) { }
protected:
	int mPeople;
};
class Ktx : public Train {
public:
	Ktx() : {}
	Ktx(int people) : {}
	~Ktx() {}
	int station(int takeOff, int takeOn) { }
	int getPeople() { }
};

int main()
{
	Ktx k;
	
	return 0;
}
*/

/* ���� 4��
class Avengers {
public:
	Avengers() {
		name = "";
		attack_point = 0;
		defense_point = 0;
		health = 0;
	}
	~Avengers() {}
	virtual void set(string _name, int _attack, int _defense, int _health) {}
	virtual int attack() { return 0; }
	virtual void defense(int _attack_point) {}
	virtual void print_info() {}
protected:
	string name;
	int attack_point;
	int defense_point;
	int health;
};

class Character : public Avengers {
public:
	int get_health() { return health; }
};

int main() {
	Character my_char;
	Character enemy_char;

	cout << endl << "--Battle--" << endl;
	cout << "My Life: " << my_char.get_health() << "\t"
		<< "Enemy Life:" << enemy_char.get_health() << endl;

	while (1) {}

	return 0;
}
*/