#include "FixedText.h"


FixedText::FixedText() : Text::Text("FIXED") {}



void FixedText::append(string _extra) {}